# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project
"""Exercise idle retirement through the real step scheduler/engine/worker/runner.

Only model loading and distributed initialization are omitted. Gates control
execution timing; observations retain weakrefs and scalar diagnostics only.
"""

import queue
import threading
import weakref
from contextlib import nullcontext
from types import SimpleNamespace

import pytest
import torch

from vllm_omni.diffusion.data import DiffusionOutput
from vllm_omni.diffusion.diffusion_engine import DiffusionEngine, DiffusionExecutionMode
from vllm_omni.diffusion.diffusion_kv.config import DiffusionKVCacheMode
from vllm_omni.diffusion.executor.uniproc_executor import UniProcDiffusionExecutor
from vllm_omni.diffusion.request import OmniDiffusionRequest
from vllm_omni.diffusion.sched import StepScheduler
from vllm_omni.diffusion.worker.diffusion_model_runner import DiffusionModelRunner
from vllm_omni.diffusion.worker.diffusion_worker import DiffusionWorker, WorkerWrapperBase
from vllm_omni.diffusion.worker.input_batch import InputBatch
from vllm_omni.inputs.data import OmniDiffusionSamplingParams
from vllm_omni.platforms import current_omni_platform

pytestmark = [pytest.mark.core_model, pytest.mark.diffusion]


class _Pipeline:
    supports_step_execution = True

    def __init__(self, device):
        self.device = device
        self.refs = {}
        self.entered: queue.Queue[tuple[str, ...]] = queue.Queue()
        self.release = threading.Semaphore(0)
        self.stopping = False

    def prepare_encode(self, state):
        state.timesteps = torch.arange(state.sampling.num_inference_steps, device=self.device)
        state.latents = torch.zeros((1, 2), device=self.device)
        # Private storage, never part of batch buffers or returned outputs.
        state.extra["private"] = torch.ones(16, device=self.device)
        self.refs[state.request_id] = (weakref.ref(state), weakref.ref(state.extra["private"]))

    def denoise_step(self, batch, **kwargs):
        assert isinstance(batch, InputBatch)
        self.entered.put(tuple(batch.request_ids))
        if not self.stopping:
            assert self.release.acquire(timeout=10), "test did not release model execution"
        # Exercise the private resource up to the last execution boundary.
        for state in batch.states:
            state.extra["private"].add_(1)
        return torch.ones_like(batch.latents)

    def step_scheduler(self, state, noise_pred):
        state.latents = state.latents + noise_pred
        state.step_index += 1

    def post_decode(self, state):
        # The result owns this tensor too: retiring the state must leave it valid.
        return DiffusionOutput(output=state.latents)


class _ObservedCondition(threading.Condition):
    def __init__(self, lock):
        super().__init__(lock)
        self.idle = threading.Event()

    def wait(self, timeout=None):
        self.idle.set()
        return super().wait(timeout)


class _Harness:
    def __init__(self, monkeypatch, device):
        self.pipeline = _Pipeline(device)
        self.runner = object.__new__(DiffusionModelRunner)
        self.runner.vllm_config = SimpleNamespace(
            kernel_config=SimpleNamespace(ir_op_priority=SimpleNamespace(set_priority=lambda *a, **kw: nullcontext())),
            compilation_config=SimpleNamespace(ir_enable_torch_wrap=True),
        )
        self.runner.od_config = SimpleNamespace(
            cache_backend=None,
            diffusion_kv_mode=DiffusionKVCacheMode.DENSE_LEGACY,
            parallel_config=SimpleNamespace(use_hsdp=False),
            streaming_output=False,
        )
        self.runner.state_cache = {}
        self.runner.pipeline = self.pipeline
        self.runner.device = torch.device(device)
        self.runner.kv_transfer_manager = None
        self.runner.input_batch = None
        if device == "cpu":
            # CPU coverage needs no accelerator or accelerator profiling API.
            monkeypatch.setattr(
                "vllm_omni.diffusion.worker.diffusion_model_runner.current_omni_platform",
                SimpleNamespace(
                    is_available=lambda: False, max_memory_reserved=lambda: 0, max_memory_allocated=lambda: 0
                ),
            )
        worker = object.__new__(DiffusionWorker)
        worker.model_runner = self.runner
        worker.lora_manager = None
        worker._step_lora_state = {}
        wrapper = object.__new__(WorkerWrapperBase)
        wrapper.worker = worker
        executor = object.__new__(UniProcDiffusionExecutor)
        executor.driver_worker = wrapper
        executor._closed = False
        executor._is_failed = False
        executor._warned_about_timeout = False
        executor._failure_callbacks = []
        engine = object.__new__(DiffusionEngine)
        engine.od_config = SimpleNamespace(
            model_class_name=None,
            max_num_seqs=2,
            request_batch_max_wait_ms=0,
            parallel_config=SimpleNamespace(data_parallel_size=1),
            diffusion_kv_mode=self.runner.od_config.diffusion_kv_mode,
            distributed_executor_backend="uni",
            streaming_output=False,
        )
        engine.scheduler = StepScheduler()
        engine.scheduler.initialize(engine.od_config)
        engine.executor = executor
        engine.execution_mode = DiffusionExecutionMode.STEP_BATCH
        engine._init_runtime_state()
        engine._init_execute_fn()
        engine._cv = _ObservedCondition(engine._rpc_lock)
        engine.stop_event = threading.Event()
        self.engine = engine
        self.gap = threading.Event()
        self.release_gap = threading.Event()
        self.pause_at_gap = False
        emit_outputs = engine._emit_outputs

        def observe_gap(*args, **kwargs):
            emit_outputs(*args, **kwargs)
            if self.pause_at_gap:
                self.pause_at_gap = False
                self.gap.set()
                assert self.release_gap.wait(10), "test did not release step gap"

        monkeypatch.setattr(engine, "_emit_outputs", observe_gap)
        self.thread = threading.Thread(target=engine._busy_loop, daemon=True)

    def add(self, rid):
        self.engine._cv.idle.clear()
        self.engine.add_request(
            OmniDiffusionRequest(
                prompt=f"prompt-{rid}",
                request_id=rid,
                sampling_params=OmniDiffusionSamplingParams(num_inference_steps=2),
            )
        )

    def step(self, expected, *, abort=None):
        assert set(self.pipeline.entered.get(timeout=10)) == set(expected)
        for rid in expected:
            assert all(ref() is not None for ref in self.pipeline.refs[rid])
        if abort is not None:
            self.engine.abort(abort)
            assert all(ref() is not None for ref in self.pipeline.refs[abort])
        self.engine._cv.idle.clear()
        self.pipeline.release.release()

    def idle(self):
        assert self.engine._cv.idle.wait(10), "engine never reached idle"
        with self.engine._cv:
            assert not self.engine.scheduler.has_requests()
        if self.pipeline.device != "cpu":
            current_omni_platform.synchronize()

    def result(self, rid, *, aborted=False):
        stream = self.engine._out_streams[rid]
        assert not stream.empty(), f"no terminal output for {rid} at idle"
        output = stream.get_nowait()
        assert output.finished and output.aborted == aborted and output.error is None
        if not aborted:
            assert torch.equal(output.output.cpu(), torch.full((1, 2), 2.0))
        self.engine._out_streams.pop(rid)
        assert all(ref() is None for ref in self.pipeline.refs[rid]), f"request resources retained for {rid}"

    def stop(self):
        # Teardown happens strictly after idle observations and assertions.
        self.pipeline.stopping = True
        self.pipeline.release.release()
        self.release_gap.set()
        self.engine.stop_event.set()
        with self.engine._cv:
            self.engine._cv.notify_all()
        if self.thread.is_alive():
            self.thread.join(10)
        assert not self.thread.is_alive()


@pytest.fixture(params=[pytest.param("cpu", marks=pytest.mark.cpu), pytest.param("cuda", marks=pytest.mark.cuda)])
def harness(request, monkeypatch):
    if request.param == "cuda" and not (current_omni_platform.is_cuda() and current_omni_platform.is_available()):
        pytest.skip("CUDA device unavailable")
    runtime = _Harness(monkeypatch, request.param)
    try:
        yield runtime
    finally:
        runtime.stop()


def test_abort_between_steps_returns_terminal_output_at_idle(harness):
    harness.pause_at_gap = True
    harness.add("gap")
    harness.thread.start()
    harness.step(["gap"])
    assert harness.gap.wait(10)
    harness.engine.abort("gap")
    harness.release_gap.set()
    harness.idle()
    harness.result("gap", aborted=True)


def test_abort_one_request_preserves_live_request(harness):
    harness.add("abort")
    harness.add("live")
    harness.thread.start()
    harness.step(["abort", "live"], abort="abort")
    assert harness.pipeline.entered.get(timeout=10) == ("live",)
    assert all(ref() is None for ref in harness.pipeline.refs["abort"])
    assert all(ref() is not None for ref in harness.pipeline.refs["live"])
    # A duplicate abort reaches the worker after another batch was built. It
    # must be harmless both to already-retired state and to the live request.
    harness.engine.abort(["abort", "abort"])
    harness.pipeline.release.release()
    harness.idle()
    harness.result("abort", aborted=True)
    harness.result("live")


@pytest.mark.parametrize("aborted", [False, True])
def test_repeated_idle_cycles_do_not_retain_private_resources(harness, aborted):
    # Each cycle must release resources before any future request or shutdown.
    for index in range(6):
        rid = f"cycle-{index}"
        harness.add(rid)
        if index == 0:
            harness.thread.start()
        harness.step([rid], abort=rid if aborted else None)
        if not aborted:
            harness.step([rid])
        harness.idle()
        harness.result(rid, aborted=aborted)


def test_failed_wave_releases_private_resources_at_idle(harness, monkeypatch, caplog):
    denoise_step = harness.pipeline.denoise_step

    def fail_denoise(batch, **kwargs):
        denoise_step(batch, **kwargs)
        raise RuntimeError("intentional denoise failure")

    monkeypatch.setattr(harness.pipeline, "denoise_step", fail_denoise)
    harness.add("error")
    harness.thread.start()
    harness.step(["error"])
    harness.idle()
    # Both pytest log handlers retain the same records. Clearing only caplog
    # leaves the report handler holding exception tracebacks and runner locals.
    for record in caplog.records:
        record.exc_info = None
    caplog.clear()
    output = harness.engine._out_streams.pop("error").get_nowait()
    assert output.finished and "intentional denoise failure" in output.error
    assert all(ref() is None for ref in harness.pipeline.refs["error"])
