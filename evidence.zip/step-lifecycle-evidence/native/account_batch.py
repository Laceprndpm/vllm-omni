# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project
"""Does a completed native OmniVoice request retain its state / CUDA tensor at idle?"""

import argparse
import asyncio
import json
import threading
import weakref

import torch

from vllm_omni.diffusion.data import OmniDiffusionConfig
from vllm_omni.diffusion.diffusion_engine import DiffusionEngine
from vllm_omni.diffusion.request import OmniDiffusionRequest
from vllm_omni.inputs.data import OmniDiffusionSamplingParams
from vllm_omni.platforms import current_omni_platform


def inventory_batch(batch):
    """Return scalar metadata only; count aliased CUDA storage once."""
    import dataclasses

    storages, visited = {}, set()

    def visit(value, path):
        if isinstance(value, torch.Tensor):
            if value.device.type != "cuda":
                return
            storage = value.untyped_storage()
            key = (value.device.index, storage.data_ptr())
            entry = storages.setdefault(key, {
                "device": str(value.device), "address": storage.data_ptr(),
                "storage_bytes": storage.nbytes(), "aliases": [],
            })
            entry["aliases"].append({"path": path, "shape": list(value.shape), "dtype": str(value.dtype)})
            return
        if id(value) in visited:
            return
        visited.add(id(value))
        if dataclasses.is_dataclass(value) and not isinstance(value, type):
            for field in dataclasses.fields(value):
                visit(getattr(value, field.name), path + "." + field.name)
        elif isinstance(value, dict):
            for key, item in value.items():
                visit(item, path + "[" + repr(key) + "]")
        elif isinstance(value, (list, tuple)):
            for i, item in enumerate(value):
                visit(item, path + "[" + str(i) + "]")

    visit(batch, "input_batch")
    snapshot = torch.accelerator.memory._snapshot()
    blocks = {
        (segment["device"], block["address"]): block
        for segment in snapshot["segments"]
        for block in segment["blocks"]
        if block["state"] == "active_allocated"
    }
    for key, entry in storages.items():
        block = blocks[key]
        entry["allocated_bytes"] = block["size"]
        entry["requested_bytes"] = block["requested_size"]
    return {
        "storages": list(storages.values()),
        "total_storage_bytes": sum(item["storage_bytes"] for item in storages.values()),
        "total_allocated_bytes": sum(item["allocated_bytes"] for item in storages.values()),
    }


async def main(model):
    config = OmniDiffusionConfig(
        model=model,
        model_class_name="OmniVoicePipeline",
        step_execution=True,
        distributed_executor_backend="uni",
        enforce_eager=True,
        max_num_seqs=1,
    )
    config.enrich_config()
    engine = DiffusionEngine(config)
    runner = engine.executor.driver_worker.worker.model_runner

    async def generate(rid):
        engine.add_request(
            OmniDiffusionRequest(
                request_id=rid,
                prompt="Hello, this is a lifecycle test.",
                sampling_params=OmniDiffusionSamplingParams(num_inference_steps=4, seed=42, extra_args={"seed": 42}),
            )
        )
        async for output in engine.get_output_stream(rid):
            assert output.error is None, output.error
            if output.finished:
                assert not output.aborted
                assert isinstance(output.output, torch.Tensor) and output.output.numel() > 0
                assert torch.isfinite(output.output).all()
                return output.output.numel()  # Keep only a scalar, not the output tensor.
        raise AssertionError("No final output")

    try:
        await engine._check_and_start_background_loop()
        print("warmup audio samples:", await asyncio.wait_for(generate("warmup"), 120), flush=True)
        current_omni_platform.synchronize()
        warmup_allocated = torch.accelerator.memory_allocated()
        refs, idle = {}, threading.Event()
        emit, wait = engine._emit_outputs, engine._cv.wait

        def observe_tensor(*args, **kwargs):
            emit(*args, **kwargs)
            state = runner.state_cache.get("probe")
            if state is not None and not refs:
                tensor = state.extra["audio_mask"]  # Created by the unmodified model.
                refs.update(
                    state=weakref.ref(state),
                    tensor=weakref.ref(tensor),
                    bytes=tensor.untyped_storage().nbytes(),
                    device=str(tensor.device),
                )
            # Locals die here; only weakrefs survive this observer.

        def observe_idle(timeout=None):
            if refs and not engine.scheduler.has_requests():
                idle.set()
            return wait(timeout)

        engine._emit_outputs, engine._cv.wait = observe_tensor, observe_idle
        samples = await asyncio.wait_for(generate("probe"), 120)
        assert await asyncio.to_thread(idle.wait, 10), "Engine did not reach idle"
        with engine._cv:
            assert not engine.scheduler.has_requests()
        current_omni_platform.synchronize()
        print("ACCOUNT " + json.dumps(inventory_batch(runner.input_batch)), flush=True)
        result = {
            "audio_samples": samples,
            "idle": True,
            "state_alive": refs["state"]() is not None,
            "audio_mask_alive": refs["tensor"]() is not None,
            "audio_mask_bytes": refs["bytes"],
            "audio_mask_device": refs["device"],
            "state_cache": list(runner.state_cache),
            "batch_requests": list(runner.input_batch.request_ids) if runner.input_batch is not None else [],
            "warmup_allocated": warmup_allocated,
            "allocated": torch.accelerator.memory_allocated(),
            "reserved": current_omni_platform.memory_reserved(),
        }
        print(
            f"GPU at idle: allocated={result['allocated']:,} bytes "
            f"({result['allocated'] / 2**20:.6f} MiB), "
            f"reserved={result['reserved']:,} bytes ({result['reserved'] / 2**20:.6f} MiB)",
            flush=True,
        )
        print(
            f"Request tensor: device={result['audio_mask_device']}, "
            f"storage={result['audio_mask_bytes']} bytes, alive={result['audio_mask_alive']}; "
            f"request state alive={result['state_alive']}",
            flush=True,
        )
        print("RESULT " + json.dumps(result), flush=True)
        assert not result["state_alive"], "Completed request state is still alive at idle"
        assert not result["audio_mask_alive"], "Model-created audio_mask is still alive at idle"
    finally:
        engine.close()  # Only after observing / asserting; never used to trigger release.


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", default="/work/models/OmniVoice")
    asyncio.run(main(parser.parse_args().model))
