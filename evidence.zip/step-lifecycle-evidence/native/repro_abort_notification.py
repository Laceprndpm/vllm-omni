# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project
"""Does the last between-step abort deliver a terminal event to its consumer?"""

import argparse
import asyncio
import json
import threading

from vllm_omni.diffusion.data import OmniDiffusionConfig
from vllm_omni.diffusion.diffusion_engine import DiffusionEngine
from vllm_omni.diffusion.request import OmniDiffusionRequest
from vllm_omni.inputs.data import OmniDiffusionSamplingParams


async def main(model):
    config = OmniDiffusionConfig(
        model=model,
        model_class_name="OmniVoicePipeline",
        step_execution=True,
        distributed_executor_backend="uni",
        enforce_eager=True,
        max_num_seqs=1,
    )
    config.enrich_config()
    engine = DiffusionEngine(config)

    async def consume(rid):
        engine.add_request(
            OmniDiffusionRequest(
                request_id=rid,
                prompt="Hello, this is a lifecycle test.",
                sampling_params=OmniDiffusionSamplingParams(num_inference_steps=4, seed=42, extra_args={"seed": 42}),
            )
        )
        async for output in engine.get_output_stream(rid):
            assert output.error is None, output.error
            if output.finished:
                return {"finished": output.finished, "aborted": output.aborted}
        raise AssertionError("No terminal output")

    task = None
    try:
        await engine._check_and_start_background_loop()
        print("warmup:", await asyncio.wait_for(consume("warmup"), 120), flush=True)
        abort_sent, idle = threading.Event(), threading.Event()
        emit, wait = engine._emit_outputs, engine._cv.wait

        def abort_after_first_step(finished_ids, scheduled_ids, runner_output, **kwargs):
            emit(finished_ids, scheduled_ids, runner_output, **kwargs)
            if "probe" in scheduled_ids and not abort_sent.is_set():
                assert "probe" not in finished_ids, "Request finished before cancellation"
                abort_sent.set()
                engine.abort("probe")  # Public cancellation API, at the real step boundary.

        def observe_idle(timeout=None):
            if abort_sent.is_set() and not engine.scheduler.has_requests():
                idle.set()
            return wait(timeout)

        engine._emit_outputs, engine._cv.wait = abort_after_first_step, observe_idle
        task = asyncio.create_task(consume("probe"))
        assert await asyncio.to_thread(idle.wait, 120), "Engine did not reach idle after abort"
        with engine._cv:
            assert not engine.scheduler.has_requests()
        # Observe the consumer without cancelling it on timeout.
        await asyncio.wait({task}, timeout=1)
        result = {
            "abort_sent": abort_sent.is_set(),
            "idle": True,
            "consumer_done": task.done(),
            "terminal": task.result() if task.done() else None,
        }
        print("RESULT " + json.dumps(result), flush=True)
        assert result["consumer_done"], "Consumer still waiting at idle after cancellation"
        assert result["terminal"] == {"finished": True, "aborted": True}
    finally:
        # Teardown must not manufacture the terminal event being tested.
        if task is not None and not task.done():
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)
        engine.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", default="/work/models/OmniVoice")
    asyncio.run(main(parser.parse_args().model))
