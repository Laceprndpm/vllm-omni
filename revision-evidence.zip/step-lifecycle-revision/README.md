# PR #8719：请求生命周期复审与验证

本文记录 [PR #8719](https://github.com/vllm-project/vllm-omni/pull/8719) 的第二轮修复，与最初的尾批张量滞留调查分开。

## 版本与证据范围

- 仓库：`vllm-project/vllm-omni`；独立分支 `fix/step-request-idle-lifecycle`。
- 本轮修复前版本：`166a5b5b58549b84e92dd45eb2d9d52222dbb411`，即开始实施时 PR #8719 的 head。
- 修复版本：`45063b541c5de050a1525b0e350e3382c1a45120`，已包含 DCO sign-off；相对本轮基线的补丁 SHA256 为 `1ae8c374450ba04b67c91f43b87736661107384f1ef257f6ce7da94dd5ed5716`。
- 最初未修复版本：`f69b1f2b19cece03f6736c7da093ea25de0e24fd`；最初原生 OmniVoice 对照见 [此前公开证据](https://github.com/vllm-project/vllm-omni/pull/8719#issuecomment-6094642162)。两种基线不能混用。
- 本轮不修改模型计算、KV 布局、attention backend 或 Pi0.5 PR #8331。
- CPU 测试使用真实 Engine、Scheduler、UniProc Executor、Worker、Runner、InputBatch，替换设备初始化和模型计算。CPU 合成张量证据不冒充原生模型证据。
- GPU 脚本使用原生预训练模型，不改写 encode、denoise、decode，也不向模型状态注入测试张量。Worker 扩展仅委派真实执行、保存弱引用和标量日志。

## 架构与问题原因

```mermaid
flowchart LR
    C[请求提交或取消] --> E[DiffusionEngine]
    E --> S[StepScheduler: 请求生命周期]
    E --> X[Executor: 串行调用和跨进程传输]
    X --> W[每个 rank 的 Worker: LoRA 请求记账]
    W --> R[Runner: state_cache 和 InputBatch]
    R --> P[模型私有张量]
    W --> E
    E --> Q[该次请求的输出队列]
    Q --> U[结果消费者]
```

Scheduler 的 `_finished_req_ids` 有一个延迟交付用途：即使 Engine 已处理终止结果、移除了旧状态，下一轮仍要向 Worker 传递旧 ID，让 Worker 先清理再接收新请求。因此不能简单地在 Engine 收尾时删除这份集合。

### 1. 旧请求的清理 ID 误伤同 ID 的新请求

这里的 `abc` 是用户提供的字符串 ID；两次使用 `abc` 是两个不同的请求实例。

1. 旧请求 `abc` 完成，Engine 取走旧状态，但 `_finished_req_ids` 仍保存 `abc`。
2. 新请求使用同一个 `abc`，被接收并处于 WAITING 状态。
3. 旧实现只检查字典里“有没有 abc”，于是把新请求也当作待终止请求；提前终止通知会删除新状态并返回缺少最终输出的错误。

即使绕过第 3 步的提前通知，下一轮调度结果仍带旧清理 ID，原 `_finalize_update_from_output()` 也可能在新请求第一步未完成时报告它已结束。

修复：终止通知必须同时确认当前状态是终态；旧 ID 仍按原机制交付 Worker。异步与同步的空调度分支也在清理和收尾前确认当前终态。

### 2. 旧终止结果可能进入新请求的队列

另一处窄窗口发生在“删除旧 Scheduler 状态”与“按 ID 查输出队列”之间。新请求可以在这个窗口注册自己的队列，导致旧终止结果被投递给新消费者。

修复：在允许 ID 重用前捕获旧队列对象，随后直接投递到这个对象。状态移除和取消信号注销在同一个 Engine 锁内完成；执行器的输出回收放在锁外，避免引入嵌套锁等待。原有消费端也按队列对象身份删除队列，不能让旧消费者删掉新队列。

### 3. Worker 记账没有跟随完成或错误退出

Runner 已清理状态并不等于 Worker 的 `_step_lora_state` 被清理。原先取消路径会显式清理，正常完成和 Runner 抛错却依赖下一轮调度，最后一批因此残留。

修复：Worker 在本轮真实返回后删除顶层 `RunnerOutput.finished` 的条目；本轮执行抛错时清除受影响的 scheduled IDs 并重抛。中间 chunk 和存活请求保留。这里删除的是请求到 adapter/scale 的记账，不是卸载 LoRA 权重，也不是重复清理 Runner。

## CPU 回归

环境：Python 3.12、vLLM 0.31.0、项目测试依赖；不需要 GPU 或模型权重。

```bash
python -m pytest -sv tests/diffusion/test_step_request_lifecycle.py \
  -m 'core_model and cpu' --run-level=core_model

python -m pytest -sv \
  tests/diffusion/test_diffusion_scheduler.py \
  tests/diffusion/test_diffusion_engine.py \
  tests/diffusion/test_diffusion_engine_cleanup.py \
  tests/diffusion/test_diffusion_engine_rpc_routing.py \
  tests/diffusion/test_diffusion_step_pipeline.py::TestWorker \
  -m 'core_model and cpu' --run-level=core_model
```

本机使用 `/tmp/step-lifecycle-venv/bin/python`，分别用 `PYTHONPATH` 指向修复前 detached worktree 和当前工作树。CPU placeholder 模型 `test` 的配置探测不使用 `HF_HUB_OFFLINE=1`，否则在测试初始化阶段就会失败。

要在本轮基线重现，先在独立 checkout 切到 `166a5b5b58549b84e92dd45eb2d9d52222dbb411`，仅应用证据包中的测试部分，生产代码保持原样：

```bash
git apply --include='tests/**' /path/to/step-lifecycle-revision/evidence/revision.patch
python -m pytest -sv tests/diffusion/test_step_request_lifecycle.py \
  -m 'core_model and cpu' --run-level=core_model
```

| 检查 | 修复前 | 修复后 | 日志 |
| --- | --- | --- | --- |
| Scheduler 旧 finished ID、终止输出原队列绑定 | 5 个目标断言失败 | 5 通过；旧 MockScheduler 后台用例也通过 | `logs/scheduler-engine-before.log`、`logs/scheduler-engine-after-focused.log` |
| Worker 完成、返回错误结果、Runner 抛错；保留 chunk/未调度请求 | 3 个目标断言失败 | 完整 TestWorker 9 通过 | `logs/worker-before.log`、`logs/worker-after.log` |
| 完成/取消各三轮同 ID 空闲重用、同批 survivor、报错后空闲 | 4 失败 | 4 通过 | `logs/lifecycle-before.log`、`logs/lifecycle-after.log` |
| 相关 Scheduler、Engine、cleanup、RPC 模块 | — | 224 通过、1 deselected | `logs/scheduler-engine-after.log` |
| 完整 step pipeline 与生命周期回归 | — | 50 通过、3 deselected | `logs/runner-lifecycle-after.log` |
| Cancellation 与真实两进程 Gloo | — | 10 通过 | `logs/request-cancellation-after-headless.log` |

最后三行是不重叠的检查范围，总计 **284 passed、4 deselected**。此前的 focused/Worker 单独运行是定位证据，不再次计入总数。

每次空闲检查发生在下一次提交和 shutdown 之前，要求终止输出已到、私有张量及请求状态弱引用失效、Worker 请求记账为空。允许保留有复用目的的 batch buffer，不断言整个 InputBatch 必须为 None。没有每请求 `gc.collect()` 或 `empty_cache()`。

错误路径最初的弱引用失败包含 pytest 日志保存 traceback 的干扰，原日志保存在 `logs/lifecycle-initial-traceback-capture.log`。正式测试仅在该用例禁止两个错误日志来源创建捕获的 traceback，保留真实异常传播和清理，再验证输出错误内容。修正后 baseline 明确在 Worker 字典残留断言失败，不能把最初的测试自持有当作框架缺陷。

## GPU 与 serving 验证

OmniVoice 单卡多进程、Qwen-Image 双卡多进程及两种模型的原生 HTTP 断连验证均已完成。

- 远端：2× A100-SXM4 80GB，Qwen-Image，TP=2、mp、step mode、max_num_seqs=2。
- 模型缓存 revision：`75e0b4be04f60ec59a75f475837eced720f823b6`；31 个文件，文件名和大小匹配，总计 57,704,594,653 字节。未宣称对这 53.74 GiB 做了完整内容哈希校验。
- 本机：原生 OmniVoice，单 GPU、mp；使用真实 serving 前端断开连接测试取消传播。
- 观察脚本：[lifecycle_observer.py](scripts/lifecycle_observer.py)。通过 Worker 扩展和真实进程收集各 rank 的状态、弱引用、`memory_allocated`、`memory_reserved`，先同步相关 GPU 工作。只读采样 RPC 不调用 Runner 下一步或清理。
- 采样 RPC 可能替换 Worker 调用循环中的上次局部返回值；因此此证据针对明确列出的 Runner/Worker 持有关系，不泛称验证了全部传输局部变量的寿命。
- C32 指客户端并发 32，Worker 实际 batch capacity 仍为 2；不能称为 B32。

本机首次 mp 启动因 OpenCV 缺 `libxcb.so.1` 失败，且失败导入污染了 spawn 的 Python 搜索路径。仅在临时 venv 安装 headless OpenCV 后重试；不作为生命周期目标失败。详见 `logs/environment-opencv-headless.log` 和对应首次 server 日志。

### OmniVoice：真实单 GPU 多进程

每个版本有 13 个空闲观察：B2 预热、单请求完成、最后请求取消、A 取消/B 完成、6 个完成/取消交替循环、3 轮 C32。模型为原生 `OmniVoicePipeline`，float32、4 步，Worker 进程独立于 Engine。

| 观察 | 修复前 166a | 修复后 45063 |
| --- | --- | --- |
| 完成后的 Worker 记账 | 9 次观察残留（含预热） | 0 次残留 |
| 取消后的 Worker 记账 | 已清理 | 已清理 |
| 每次空闲的 state / 被观察私有张量 | 均已释放 | 均已释放 |
| 每次空闲 allocated | 3,545,060,352 B | 3,545,060,352 B |
| 每次空闲 reserved | 4,299,161,600 B | 4,299,161,600 B |

两版已经包含最初的 Runner 释放修复，因此本轮显存数值相同；这不能被描述为新的显存收益。两版的 55 个完成输出（含 48 个 C32 存活请求）逐位相同，均为有效的 47,040 点音频张量。四步结果只验证张量正确性，不作主观语音质量结论。

最终 C32 三轮耗时分别是修复前 1.777/1.787/1.772 秒、修复后 1.702/1.730/1.717 秒；InputBatch.make_batch 主机计时 p50 是 0.190/0.170 ms。此前反向执行顺序测出了相反方向的差异，因此不声称稳定加速或减速。计时包括观察与输出处理，不能替代独立吞吐基准，更不是 GPU kernel 计时。

详细命令和全部数据见 [OmniVoice 验证记录](evidence/omnivoice-validation.md)、`evidence/omnivoice-comparison.json`。

### OmniVoice：真实前端断连

原生 `/v1/audio/speech` 的预热返回 200 和 24 kHz WAV。随后提交 128 步请求，在真实执行后关闭 TCP；脚本没有直接调用 Engine.abort。实际传播链为：

```text
TCP close → serving with_cancellation → AsyncOmni / Orchestrator abort
→ InlineStageDiffusionClient → DiffusionEngine.abort → mp Worker.release_step_requests
```

这是 inline stage client 加独立 mp Worker，不冒充子进程 stage client。Worker 清理前的 `cache_before` 明确包含目标 ID，排除了对已正常完成请求的迟到取消；清理发生于断连后约 61.2 ms。空闲时各请求状态和被观察私有张量均释放，allocated/reserved 为 3,545,060,352 / 4,299,161,600 字节，测量在下一请求或 shutdown 之前。

HTTP 用例的客户端已主动断开，验证的是服务端取消传播与清理，不是 HTTP 消费者挂起。仍在运行的 Engine API 消费者是否收到终止事件，由 CPU 回归和直接 Engine 原生模型脚本单独检查。

### Qwen-Image：真实双 GPU 多进程

使用 2× A100-SXM4 80GB，原生 QwenImagePipeline，TP=2、SP/CFG/DP=1、BF16、eager、512×512、20 步、seed=42、true_cfg_scale=4；执行容量为 2。场景与 OmniVoice 相同，每版 13 个空闲观察，记录两个 rank。

| 每个 rank、每次空闲 | 修复前 166a | 修复后 45063 |
| --- | --- | --- |
| Worker 请求记账残留的观察次数 | 9（含预热） | 0 |
| 被观察请求状态 / 私有张量存活 | 0 | 0 |
| allocated | 42,916,440,576 B | 42,916,440,576 B |
| reserved | 44,379,930,624 B | 44,379,930,624 B |

没有缺失的请求观察记录；不是对空 weakref 集合做断言。修复后的正式矩阵退出码为 0。55 个对应完成输出的张量哈希在修复前后完全一致，其中包括三轮 C32 的 48 个完成请求。每轮 16 个完成、16 个取消。Qwen 的单独执行 B 与同批存活 B 并不逐位相同，不能把跨 batch 的数值差异描述为此次修复造成；这里的输出一致性比较严格对应相同配置的修复前后运行。

C32 三轮耗时：修复前 54.630 / 54.653 / 54.131 秒，修复后 54.926 / 54.186 / 54.214 秒。每轮实际调度为 batch=2 的 167 次和 batch=1 的 2 次，共 169 次 make_batch 调用；该函数也处理缓存复用，不能把这些调用全称为完整重建。rank 0 的每轮 host p50 在 0.154–0.170 ms，host 总计约 53–56 ms，没有测出明确的性能变化。两版都已有最初的 Runner 清理，这些数据不能量化最初引入清理的增量开销。

运行依赖为 Python 3.12.3、vLLM 0.31.0、torch 2.13.0+cu130、transformers 5.14.1、diffusers 0.40.0。环境中 flashinfer-python 0.7.0.post1 与 flashinfer-cubin 0.6.18.post1 版本不匹配，框架捕获该导入错误后禁用了可选 ring backend；本次 TP=2/SP=1 路径正常运行，两版环境一致。没有验证该可选后端。

在仓库根目录解压证据包后，使用完整 Qwen-Image 权重和新的输出目录：

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:./step-lifecycle-revision/scripts \
python step-lifecycle-revision/scripts/native_lifecycle.py \
  --model /path/to/Qwen-Image --model-class QwenImagePipeline \
  --tp 2 --dtype bfloat16 --steps 20 --c32 --c32-rounds 3 \
  --output-dir ./lifecycle-results/qwen-after

python step-lifecycle-revision/scripts/http_qwen_cancel.py \
  --repo . --model /path/to/Qwen-Image --steps 20 --port 18081 \
  --output-dir ./lifecycle-results/qwen-http-after
```

### Qwen-Image：真实前端断连

修复前后分别启动原生 `/v1/images/generations` 服务，预热请求返回可解码的 512×512 图像。随后请求的 TCP 连接在真实执行后关闭，目标只执行 2/20 步；两个 rank 的 release 前 cache 都包含目标 ID。断连到最后一个 rank 释放分别约为 274.8 / 276.8 ms。

两版均在下一请求或 shutdown 之前观察到：Runner cache、InputBatch 请求成员、Worker 记账为空，请求状态和私有张量弱引用失效；每个 rank 的 allocated/reserved 与预热空闲值相同，allocated 变化为 0 B。这个测试检验真实服务取消和 collective cleanup RPC；两版均通过是预期结果，因为本轮基线已包含取消清理修复。

远端原 supervisor 服务已恢复，2026-10-11 04:25:06 UTC 健康检查返回 HTTP 200。

逐 rank 数据见 [idle-memory.csv](evidence/qwen/idle-memory.csv)、`evidence/qwen/{native,http}-{before,after}`；完整环境、命令与服务恢复记录见 [Qwen 验证报告](evidence/qwen/validation.md)。

## 显存结论应如何理解

在本例中，如果仍存活的是拥有 CUDA 存储的模型私有 Tensor，而且 InputBatch/请求状态是保留它的原因，那么对应 CUDA allocation 仍然占用，不能被 allocator 当作空闲块复用。弱引用能证明对象仍存活；设备、底层存储和 allocated 的联合观察能支持这里的显存结论。

这不等于所有 Python 引用都占显存，也不等于 `reserved` 不下降就是泄漏。旧原生 OmniVoice 结果是 22.5 KiB 的固定尾批滞留，尚未证明无界增长。Worker 的 `(None, 1.0)` 请求记账本身是 CPU 元数据，不能据此声称新增 GPU 泄漏。

## 提交检查

已按仓库测试工作流和 PR 自检工作流执行。全仓 pre-commit 在独立 worktree 中运行，避免自动修复污染本次分支；它报告了仓库已有的文档、类型、测试标记、shell 与 SPDX 问题。修改文件的适用 hooks 均通过，除了 mypy 的 **52 个基线已有诊断**：去除行号偏移后，修复前后诊断相同，无新增项，详见 `logs/mypy-comparison.json`。不得将全仓检查描述为全通过。

[独立审查记录](precheck-review.md)说明了锁、队列身份及观测脚本边界。本次覆盖正常完成和 Runner 错误；没有声称解决 LoRA activation 或 profiler 自身抛错时所有资源的收尾，也没有改造外部迟到字符串 ID 取消的完整 generation 协议。Ray backend 未验证。

AI 辅助：Codex 编写修复、测试、脚本和报告。实际执行与未执行的验证分别列出。
