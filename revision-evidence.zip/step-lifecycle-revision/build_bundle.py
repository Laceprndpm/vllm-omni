# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project
"""Build the supplementary evidence archive, excluding weights and output tensors."""

import hashlib
import json
import re
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT.parent / "vllm-omni-step-lifecycle-revision-evidence.zip"
SECRET = re.compile(
    rb"(?:hf_[A-Za-z0-9]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}"
    rb"|-----BEGIN [A-Z ]*PRIVATE KEY-----|Authorization:\s*Bearer\s+\S+)",
    re.I,
)


def main():
    files = {}
    # Text evidence is sufficient to check allocations, request identity and
    # output hashes. Model weights and generated .pt files stay out of the ZIP.
    allowed = {".py", ".md", ".log", ".json", ".jsonl", ".yaml", ".patch", ".txt", ".csv"}
    for directory in ("scripts", "logs", "evidence"):
        for path in sorted((ROOT / directory).rglob("*")):
            if path.is_file() and path.suffix in allowed and "__pycache__" not in path.parts:
                if any(marker in str(path.relative_to(ROOT)) for marker in (
                    "first-observation", "startup-failed", "harness-failed", "serving-cli-help",
                )):
                    continue  # Setup investigations remain available locally.
                # Duplicate source patches were saved by individual harnesses;
                # the exact production and regression patches are packaged once.
                if path.name in {"source.patch", "remote-after.patch", "production.patch", "regression-tests.patch"}:
                    continue
                files[str(path.relative_to(ROOT))] = path.read_bytes()
    for name in ("README.md", "precheck-review.md", "build_bundle.py"):
        files[name] = (ROOT / name).read_bytes()
    for name, data in files.items():
        if SECRET.search(data):
            raise SystemExit(f"Credential pattern found in {name}; archive not published")
    files["SHA256SUMS"] = "".join(
        f"{hashlib.sha256(data).hexdigest()}  {name}\n" for name, data in sorted(files.items())
    ).encode()
    with zipfile.ZipFile(OUTPUT, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(f"step-lifecycle-revision/{name}", date_time=(2026, 10, 11, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, data)
    with zipfile.ZipFile(OUTPUT) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(files)
    result = {
        "path": str(OUTPUT), "files": len(files), "bytes": OUTPUT.stat().st_size,
        "sha256": hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),
    }
    (ROOT / "bundle.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
