# Native OmniVoice multiprocessing and HTTP validation

The final observations use the same `lifecycle_observer.py` in both source trees.
Model computation (`prepare_encode`, `denoise_step`, `step_scheduler`, decoding)
and framework cleanup are unchanged. The observer delegates Worker calls and
records weak references, bookkeeping and synchronized allocator counters.

- Reviewed PR head: `166a5b5b58549b84e92dd45eb2d9d52222dbb411`.
- Follow-up: `45063b541c5de050a1525b0e350e3382c1a45120`.
- Hardware: one NVIDIA GeForce RTX 4060 Laptop GPU, 8,188 MiB.
- Runtime: Python 3.12.14, vLLM 0.31.0, native `OmniVoicePipeline`, `mp`, float32,
  eager execution, four steps; request capacity two.
- Weights: `k2-fsa/OmniVoice`, revision `c5fdb5ccb189668d56333f77ba2629f4cd7535f4`.
  Weight checksums and source/script fingerprints are in each `manifest.json`.

## Direct Engine matrix

Run from either checkout, replacing `REPO` and the output directory:

```bash
cd REPO
PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=/work/step-lifecycle-revision/scripts:REPO \
/tmp/step-lifecycle-venv/bin/python \
  /work/step-lifecycle-revision/scripts/native_lifecycle.py \
  --model /work/models/OmniVoice --model-class OmniVoicePipeline \
  --tp 1 --dtype float32 --steps 4 --c32 \
  --output-dir /work/step-lifecycle-revision/evidence/NEW-DIRECTORY
```

Thirteen observations per arm: B2 warmup, lone completion, last-request abort,
abort A while its same-batch peer B survives, six alternating completion/abort
idle cycles, and three rounds of 32 submitted requests with 16 cancellations.
**C32 means 32 outstanding submissions, with execution capacity two; it is not
a batch of 32.** Every idle observation precedes the next request and shutdown.
Snapshots use a read-only Worker RPC; they do not schedule Runner work or invoke
cleanup. Shared `timesteps` buffers remain visible but are excluded from the
request-private tensor assertion.

| Observation | Reviewed head | Follow-up |
| --- | --- | --- |
| Normal completion / surviving B / completed cycles | Worker LoRA entry remains | No request entry remains |
| Last cancellation / cancelled cycles | Clean | Clean |
| Last completed C32 request | Worker LoRA entry remains | No request entry remains |
| State and private tensor weakrefs at every idle | Dead | Dead |
| Allocated bytes at every observed idle | 3,545,060,352 | 3,545,060,352 |
| Reserved bytes at every observed idle | 4,299,161,600 | 4,299,161,600 |

All 55 completed native outputs, including 48 C32 survivors, are bitwise equal
between the two arms. Each is a finite, nonempty 47,040-sample tensor. The B2
survivor also matches the independent completion with the same prompt and seed.
This checks tensor correctness, not perceptual speech quality at four steps.

Before exits 1 because nine idle observations (including warmup) detect Worker
metadata retention; after exits 0 with no failed observations. Runner state and
private tensors already release correctly at the reviewed PR head. The equal
allocator numbers therefore do not indicate a new GPU memory leak from the
Worker bookkeeping defect.

Final C32 times before: 1.777 / 1.787 / 1.772 s; after: 1.702 / 1.730 / 1.717 s.
Framework `InputBatch.make_batch` host p50: 0.190 / 0.170 ms. An earlier run in
the reverse order measured 1.77–1.86 / 1.96–2.05 s and 0.182 / 0.198 ms, retained
under `*-first-observation`. These short instrumented runs do not establish a
stable speedup or slowdown. Both versions already contain shared Runner cleanup;
this comparison measures the review follow-up, not the original cleanup change.

Evidence: `omnivoice-mp-{before,after}/{cases.jsonl,rank-0.jsonl,summary.json}`,
`omnivoice-comparison.json`, and corresponding logs. CPU output artifacts are
saved as `.pt`; the JSON files include output hashes.

## Real serving disconnect

```bash
cd /work/vllm-omni
/tmp/step-lifecycle-venv/bin/python \
  /work/step-lifecycle-revision/scripts/http_omnivoice_cancel.py \
  --output-dir /work/step-lifecycle-revision/evidence/NEW-HTTP-DIRECTORY
```

The script starts the native CLI server with the repository OmniVoice deploy
configuration, enabling step execution and the observation extension. Warmup
returns HTTP 200 and a finite 48,960-sample, 24 kHz WAV. Its idle snapshot is
matched to that warmup request ID. A second speech request uses 128 steps; after
the worker records real execution, the client closes the TCP connection.

Actual propagation on this one-stage deployment:

```text
TCP close -> /v1/audio/speech @with_cancellation -> AsyncOmni.generate cancellation
 -> Orchestrator abort -> InlineStageDiffusionClient.abort_requests_async
 -> DiffusionEngine.abort -> mp Worker.release_step_requests
```

The stage client is inline but the Worker is a separate process (server PID
15877, Worker PID 16058). The target ID is present in `release.cache_before`,
proving cancellation reached an active request, rather than a request that had
already completed. The release occurs 61.2 ms after socket closure. The ensuing
idle snapshot, before shutdown or any new request, has empty Runner cache/batch
and Worker bookkeeping, dead request state/private tensor weakrefs, allocated
3,545,060,352 bytes and reserved 4,299,161,600 bytes.

Evidence: `omnivoice-http-after/{result.json,rank-0.jsonl,server.log,manifest.json}`.
The script never calls `engine.abort` itself. Its final server shutdown happens
only after the cancellation and idle assertions.

## Setup failures retained separately

- `omnivoice-http-startup-failed-cv2`: full OpenCV lacked `libxcb.so.1`; its failed
  import polluted `sys.path` and broke multiprocessing spawn. Installing
  `opencv-python-headless==5.0.0.93 --no-deps` into the temporary venv fixed it.
- `omnivoice-mp-startup-failed-context`: the initial standalone harness did not
  establish a uniform spawn context. Its main entry point now does so.
- `omnivoice-mp-harness-failed-snapshot`: the first harness assumed a flat RPC
  reply, while collective RPC wraps the gathered snapshots in a response list.

These are environment/harness failures, not lifecycle defect reproductions.
No repository production changes were made to resolve them. This local evidence
is single-GPU multiprocessing evidence; it does not substitute for the separate
two-GPU validation.
