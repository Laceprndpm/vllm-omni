# Native Qwen-Image: real TP2, multiprocessing and HTTP validation

The follow-up passes the native two-GPU lifecycle matrix. The reviewed PR head
reproduces delayed Worker bookkeeping cleanup on normal completion; it already
releases the Runner states and observed private tensors. This follow-up does
not produce additional GPU-memory savings in this model/configuration.

## Frozen inputs and environment

- Reviewed head: `166a5b5b58549b84e92dd45eb2d9d52222dbb411`.
- Follow-up: `45063b541c5de050a1525b0e350e3382c1a45120`.
- Applied patch SHA256: `1ae8c374450ba04b67c91f43b87736661107384f1ef257f6ce7da94dd5ed5716`.
- Model: `Qwen/Qwen-Image`, complete cached revision
  `75e0b4be04f60ec59a75f475837eced720f823b6`; no new weight download.
- Hardware: two NVIDIA A100-SXM4-80GB, 81,920 MiB each, driver 595.91.07.
- Python 3.12.3, PyTorch 2.13.0+cu130, vLLM 0.31.0,
  Transformers 5.14.1, Diffusers 0.40.0.
- Native `QwenImagePipeline`, `mp`, tensor parallelism 2, sequence parallelism 1,
  BF16, eager, step execution, request capacity 2, 512×512, 20 steps,
  seed 42, true CFG scale 4, negative prompt `blurry`.

The original `/venv/main` was unchanged. A separate environment overlaid vLLM
0.31.0 and its needed Python packages while reusing the base environment's
PyTorch/CUDA dependencies. FlashInfer Python is 0.7.0.post1, but the inherited
optional cubin package is 0.6.18.post1. The configured package index did not
provide a matching cubin. The framework reports FlashInfer ring kernels as
unavailable; this TP2/SP1 run does not validate that optional ring backend.
Both source trees use exactly the same environment and scripts.

Each `qwen/{native,http}-{before,after}/run-manifest.json` records the executable
command, software/hardware, production file hashes, model revision and script
hashes. Its `scripts/` directory preserves the scripts used at launch. Production
hashes were checked against the two local Git trees, and all four runs have
identical observer/native/HTTP script hashes.

## Measurement path and limits

`native_lifecycle.py` uses the real `DiffusionEngine`, `StepScheduler`,
multiprocessing executor, two Workers, Runner, InputBatch and pretrained model.
The observer subclasses the existing Worker extension and Engine extension
points. It delegates all execution and release calls to their original methods.
Model encode, denoise, scheduler update and decode are not replaced.

The observer records weak references to actual request states and selected
private tensors (`extra`, prompt embeddings and negative embeddings). In this
Qwen run, the observed private CUDA tensors are prompt embeddings. Every
submitted request is represented: at the last idle point each rank has 109
observed states, including startup warmup, and 217 private tensor observations.
All are dead at every applicable idle snapshot. Shared CPU `timesteps` remain
visible but are excluded from private-resource assertions because the pipeline
scheduler intentionally retains its reusable schedule.

Idle snapshots synchronize GPU work and collect scalar metadata plus
`memory_allocated`/`memory_reserved` on each rank. They happen before a subsequent
request or Engine shutdown. They do not schedule Runner work or call cleanup.
The read-only snapshot RPC can replace the Worker dispatch loop's previous
returned local, so the assertions cover the named Runner/Worker owners, not
every possible output-local reference. No `gc.collect()` or `empty_cache()` is
used. Reserved allocator memory is reported as a cache, not classified as a leak.

## Direct Engine results

Each arm observes 13 idle boundaries: B2 warmup; one completion; last-request
abort; abort A while same-batch B completes; six alternating completion/abort
idle/resume cycles; and three C32 mixed completion/cancellation rounds.
**C32 means 32 outstanding submissions and capacity two, not batch size 32.**

| Observation | Reviewed head | Follow-up |
| --- | --- | --- |
| Normal completion, surviving B, completed cycles and C32 tail | Worker LoRA metadata remains on both ranks | All request bookkeeping empty |
| Last cancellation and cancelled cycles | Clean | Clean |
| Runner cache, InputBatch request rows/states at every idle | Empty | Empty |
| Observed state and private tensor weakrefs at every idle | Dead | Dead |
| Terminal consumers | All exit with expected completion/abort | All exit with expected completion/abort |

The reviewed head exits 1: nine observations, including warmup, detect retained
metadata. `summary.failed_cases` lists eight because warmup is recorded separately
in `cases.jsonl`. The follow-up exits 0; all 13 observations were checked.

| Rank | Idle allocated, both arms | Idle reserved, both arms | Follow-up live states/private tensors/Worker entries |
| --- | ---: | ---: | --- |
| 0 | 42,916,440,576 B (39.969 GiB) | 44,379,930,624 B (41.332 GiB) | 0 / 0 / 0 |
| 1 | 42,916,440,576 B (39.969 GiB) | 44,379,930,624 B (41.332 GiB) | 0 / 0 / 0 |

These allocator values are identical at all 13 boundaries, including repeated
idle/resume and C32. They are model/runtime allocations, not request leakage.
Raw per-rank data is in `qwen/idle-memory.csv` and each arm's JSONL files.

All **55 completed native output tensors** have matching SHA256 values between
before and after, including all 48 C32 survivors. Each output is finite with
shape `[1, 3, 512, 512]`. The independently executed B1 output and a B2 survivor
are not bitwise equal even before the fix (mean absolute difference 0.005115,
maximum 1.044922); cross-batch equality is not claimed. The correctness comparison
uses corresponding requests and execution waves across the two revisions.

| C32 round | Before wall time | After wall time | Before/after completed and aborted |
| --- | ---: | ---: | --- |
| 0 | 54.630 s | 54.926 s | 16 / 16 |
| 1 | 54.653 s | 54.186 s | 16 / 16 |
| 2 | 54.131 s | 54.214 s | 16 / 16 |

Every round has 167 execution waves of two requests and two waves of one.
Wall-time medians are 54.630 s before and 54.214 s after (-0.76%). Three sequential
rounds do not establish a speedup. Rank-0 host wall time inside the original
`InputBatch.make_batch` has per-round medians of 0.154–0.170 ms before and
0.159–0.167 ms after; totals are 53.1–55.7 ms per round. No clear before/after performance change is established. Both revisions already
contain the original Runner cleanup; these measurements do not quantify that
cleanup's incremental repacking cost. This measures host dispatch, not CUDA
kernel duration. The separate
`_prepare_batch_inputs` timing includes encoding and must not be called repacking
cost. Exact values are in `qwen/comparison.json`.

## Native HTTP frontend cancellation

`http_qwen_cancel.py` starts the unmodified serving CLI on temporary port 18081
with TP2/mp/step/BF16/eager and stage-zero `max_num_seqs=2`. It first validates a
real `/v1/images/generations` response as a 512×512 PNG. Then it sends a new image
request over a real TCP connection, waits for a Worker execution event, and
closes the socket. Both Workers must record the target ID in `cache_before`
when cancellation cleanup begins. The target actually executes two of its
requested 20 steps in each arm, so this is not a late abort after completion.

| Observation | Before | After |
| --- | ---: | ---: |
| TCP disconnect → last rank release | 274.8 ms | 276.8 ms |
| Active ID present before release, both ranks | Yes | Yes |
| Idle cache/InputBatch/LoRA entries, both ranks | 0 | 0 |
| Idle observed target state/private tensor refs | Dead | Dead |
| Per-rank allocated change from warmup idle | 0 B | 0 B |
| Measured before server shutdown | Yes | Yes |
| Harness exit status | 0 | 0 |

All HTTP idle snapshots have the same per-rank allocated/reserved numbers as the
direct Engine table. Warmup PNGs have the same SHA256:
`28b7c8c980a421dc833c02f47d263e5550184a94ced11556589d1e4e1494aa3b`.
Before's warmup completion also records the known lingering Worker metadata;
the following cancellation is clean on both revisions. Raw frontend logs,
active-before-release events and results are under `qwen/http-{before,after}`.

## Reproduction

Use Python 3.12, vLLM 0.31.0 and the matching project dependencies, two supported
GPUs and complete `Qwen/Qwen-Image` weights. Run from either source checkout with
the scripts available on `PYTHONPATH`; always choose a fresh output directory.

```bash
PYTHONPATH=.:/path/to/step-lifecycle-revision/scripts \
HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 \
python /path/to/step-lifecycle-revision/scripts/native_lifecycle.py \
  --model /path/to/Qwen-Image --model-class QwenImagePipeline \
  --tp 2 --dtype bfloat16 --steps 20 --c32 --c32-rounds 3 \
  --output-dir /path/to/fresh-native-results

python /path/to/step-lifecycle-revision/scripts/http_qwen_cancel.py \
  --repo . --model /path/to/Qwen-Image --port 18081 --steps 20 \
  --output-dir /path/to/fresh-http-results
```

Native before's exit 1 is expected for the identified Worker metadata defect.
The matching after command and both HTTP commands exit 0. The evidence excludes
model weights and `.pt` output arrays; hashes and numerical summaries remain.

Harness setup failures were preserved separately under `setup-debug/qwen`:
spawn-context initialization, an initially misunderstood collective-RPC result
envelope, and an overly broad assertion against shared timesteps. They are not
counted as product failures. The final runs use the corrected, identical scripts.

The original supervisor service was restarted after all measurements and reached
`RUNNING` (PID 12973). Its port-18000 `/health` returned HTTP 200 at
2026-10-11 04:25:06 UTC, 66 seconds after restart. The status and health
verification are recorded in `qwen/service-restored.txt`.
