# Step lifecycle revision: independent precheck

审查时间：2026-10-11T04:10:45.777426+00:00。生产代码：`45063b541c5de050a1525b0e350e3382c1a45120`；对照 PR head：`166a5b5b58549b84e92dd45eb2d9d52222dbb411`。

本轮为只读源码、脚本及既有日志审查，未再执行模型、修改生产代码或验证脚本。下面明确区分已验证行为、观察脚本的范围及未覆盖路径。

## 生产修复：已检查的边界

- Scheduler 仍是请求生命周期唯一所有者。`pending_finished_request_ids()` 和 `update_from_output()` 根据当前请求的终态判断通知，不把旧 Worker cleanup ID 当作新 WAITING/RUNNING 请求的结束依据。
- `_finished_req_ids` 仍随调度波发送，Worker 先消费旧清理记录，再安装新请求。未通过清空此集合掩盖复用问题，也未新增全局 generation 协议。
- 异步和同步空调度分支先过滤当前终态，再做 KV 清理和最终输出处理。仅依赖 KV generation 不够：错误的旧 ID 可以查到新请求的 generation，因此过滤必须先发生。
- 异步终止投递先捕获旧 queue；finalizer 在 `_cv` 内移除旧 Scheduler 状态并释放 cancellation signal，之后锁外调用 `drop_output()`；输出投递到捕获的 queue。单 busy-loop 是终止状态的唯一移除者，因此两段短临界区间内 admission 不能先行复用尚存的旧状态。
- 同步 finalizer 的返回类型和 async-output 等待行为不变。没有在异步路径新增 `_cv` 与 executor Future 锁的嵌套。
- Runner 的共用释放只删除指定请求的 state cache，并在受影响时使缓存 batch 失效；仍存活的同批请求保留自己的 state，下一步重新打包。结果对象继续持有输出张量，不靠每请求 GC 或 empty_cache 释放。
- Worker 本轮新增覆盖：真实 Runner 正常返回终止结果、逐请求错误结果、Runner 调用整体抛异常时的 `_step_lora_state` 收尾；取消继续走串行 cleanup RPC。存活请求的 Worker 条目保留。

**明确限制：** Worker 的 LoRA activation 和 profiler 错误不在此次 Runner 异常收尾的完整覆盖声明内。adapter 加载可在 Runner 调用前失败，profiler.step 可在 Runner 返回后失败；这些路径与 Runner 私有状态清理还有独立边界。本 PR 没有只顺带清元数据，就声称这些路径的全部资源已正确释放。迟到的外部字符串 ID abort、所有 API 的全链路 generation 身份协议也不在本次范围内。

对上述已改路径，没有发现新的确定性 blocking 问题。这不替代尚在运行的双 GPU 结果核验。

## 已保存 CPU 证据

| 日志 | 结果与含义 |
| --- | --- |
| `logs/scheduler-engine-before.log` | baseline 新增/增强回归 5 failed：提前通知复用 ID、执行一步后误报 finished、三条终止投递分支把旧结果发给新 queue |
| `logs/scheduler-engine-after-focused.log` | 相同五项与旧 MockScheduler 后台循环测试，共 6 passed |
| `logs/scheduler-engine-after.log` | Scheduler、Engine、cleanup、RPC routing 四模块 CPU：224 passed、1 deselected |
| `logs/request-cancellation-after.log` | 首轮 9 passed、1 failed：spawn 子进程在导入 typing 时进入 cv2/typing，并因缺 libxcb 失败；尚未进入 Worker/collective，属于环境错误 |
| `logs/request-cancellation-after-headless.log` | 临时 venv 安装 headless OpenCV 后，从新 Python 进程重跑，10 passed，包括真实两进程 Gloo |

Gloo 是 CPU 进程组验证，不能称为双 GPU step-mode 验证。未重复运行这些已通过 CPU 检查。

## 观察脚本是否改变引用或触发清理

`lifecycle_observer.py` 对原生 Worker、Runner 的 prepare、InputBatch.make_batch 进行委托包装，不替换模型 encode/denoise/step/decode，也不替换框架清理实现。

- 持久记录包含 weakref、请求 ID、张量设备/shape/storage 字节数等标量。没有把 StepRequestState 或请求张量加入 Mock call history、结果历史或异常列表。
- 包装器持有 Worker/Runner 本身，临时 state/tensor 循环变量在步骤返回后消失。每个 mp Worker 进程仅有一个该观察器；不要把这个全局 classmethod timing 包装直接复用成多引擎长期观测服务。
- snapshot 先等待相关设备工作完成，再读缓存、batch、Worker 元数据及 allocated/reserved；all_gather_object 只在 CPU group 上交换标量字典，不调 schedule、Runner execution 或 release，也不调用 GC/empty_cache。
- 原生 Driver 的 idle 事件只用于定位边界。随后 `_cv` 内再次检查 Scheduler 空闲；请求消费者结束后才做手动 snapshot。自动 idle snapshot 本身也在任何新请求和 shutdown 之前发生。
- 捕获的是成功步骤返回时仍存活的状态及指定字段（extra、prompt embeds、timesteps，容器递归深度有限）。不是任意模型所有分配的完整堆遍历；单步即完成或首步即抛异常的请求可能来不及被 weakref 观察。因此具体 evidence 必须确认目标请求确实有观察记录。本机 native 数据已确认不是空集合断言。
- timesteps 可能属于可复用模型缓存，仍记录其存活情况，但不作为请求私有张量强制释放。weakref 检查 Python 张量对象，storage 字节数可能因别名重复；不能直接将这些字段求和等同 allocated。allocated 与 reserved 是独立的 allocator 读数；reserved 不等于泄漏。
- 观察器的历史 weakref/标量及计时列表会随有限测试历史增长，这是测试侧 CPU 记录，不是请求张量引用链。不要用此进程的总 RSS 推断框架无界泄漏。

## 脚本审查发现及处理

1. `native_lifecycle.run_case` 初版在 `_cv` 外清 idle event，可能被旧 idle wait 重设导致假失败。已通知验证 agent；复读当前脚本确认移到 admission 的同一 `_cv` 内。
2. 初版 HTTP 只看到第一步曾活跃，不能排除关闭连接前已正常完成。已通知验证 agent；当前 observer 记录 cleanup 前的 `cache_before`，HTTP 断言目标仍在其中且 release 晚于断连。
3. HTTP warmup 初版接受任意 snapshot，可能误取启动空闲记录。当前已根据 warmup 文本解析实际请求 ID，再匹配含该 ID 观察记录且在其步骤之后的 snapshot。
4. Worker collective RPC 的外层结果 envelope 当前已处理；每 rank snapshot 不同会显式失败。
5. 脚本采用 append JSONL，每次运行必须使用新 output-dir；已有记录不能与新 run 混用。部署脚本、source manifest、模型 revision 与日志应一起归档。

以上改动由验证 agent 完成，本审查者没有修改脚本。

## 可用 native 证据及声明上限

本机已完成的 OmniVoice mp 前后证据中，每个场景都有非空 weakref 观察。baseline `166a` 已包含原 Runner 张量释放修复，因此本轮看到的是正常完成后 Worker LoRA 条目残留：before 完成/存活者/完成循环等场景留下条目，after 清空。`omnivoice-comparison.json` 中前后 allocated 都为 3,545,060,352 bytes、reserved 都为 4,299,161,600 bytes；这支持本轮 Worker 修正是记账收尾，不能包装为新增 GPU 内存泄漏或显存降幅。

已人工核查首轮 `omnivoice-http-after` 原始 trace：warmup 正常跑四步后进入 idle-wave-4；128 步取消请求只运行两步（step_id 6、7），最后一个 step 的 cache 仍包含它，随后才发生 release 和 idle-wave-6。记录的 disconnect→release 为约 42.2 ms。因此该已完成 run 有证据证明活跃请求被前端断连取消，不是迟到空清理。当前增强脚本让此条件可自动断言。

C32 是 **32 个同时排队的请求、max_num_seqs=2**，三轮使用不同 ID；实际执行 batch 至多为 2。它能验证混合完成/取消排队及重复空闲，不能称为实际 B32 合批或容量 32 的 repacking 测试。

正常输出的 finite/shape/terminal 检查是有效性检查，不是语音/图像质量评价。单请求与同批存活者的数值比较仅打印差异，没有预设跨 batch 的 bitwise 相等要求；不能仅靠 failed_cases=[] 声称两种执行形态数值相等。本机额外的 before/after 同配置输出文件比较记录为逐元素相等，这是更直接的“此次修改未改变本例输出”的证据。

prepare/make_batch 的计时是 host wall time，GPU kernel 可能异步执行，且包含测试包装/日志带来的运行扰动。脚本 summary 已注明不是 CUDA kernel duration。可报告样本值和前后差异，不应由几轮数据得出 GPU repacking 没有开销、吞吐性能无回退的结论。

本轮未自行重复执行模型或远程双卡任务。远程 Qwen TP2 和其 HTTP 各 rank 最终结果仍应由运行 agent 检查后归档，不能从本机单卡结果推断。

## 本轮复读脚本指纹

| 文件 | SHA-256 |
| --- | --- |
| `lifecycle_observer.py` | `1360e5229cb198d697475ba50d37ca9afd3adca4159f3f50c3c21ca187b94ebf` |
| `native_lifecycle.py` | `1d9de1b930f09b5f6099737dd028f1637e58d84d3f1b20420863980c36e7dfce` |
| `http_omnivoice_cancel.py` | `078c1853e4ee0ea35ec76b0e48b65d0adbf054fe7c8fa3dc7a5aa0dbaac6ad6f` |

后续如果这些脚本继续修改，应连同实际运行使用的副本／指纹保留；本报告不能代替对新版本的核查。

## 最终双卡证据独立审查（2026-10-11）

本节补充核查已完成的 `evidence/qwen/{native,http}-{before,after}`，覆盖前文“远程结果仍在运行”的状态。没有重新运行模型、修改生产代码或验证脚本；只读取 Git 对象、运行时 manifest、原始 JSONL、汇总文件及发布草稿，用独立断言重新计算以下结果。当前工作树为干净的 `45063b541c5de050a1525b0e350e3382c1a45120`。

### 来源与运行配置

- 四个运行目录分别记录的 Engine、BaseScheduler、Worker、Runner SHA-256，逐一与 `git show 166a…:path` 或 `git show 45063…:path` 的实际字节哈希相同。它们包含本轮全部三个生产修改文件，以及两版未变的 Runner。不能据此宣称对运行环境的任意其他文件做了完整取证。
- 四臂 manifest 的四份脚本哈希均与各自归档副本及当前共享 `scripts/` 中的字节一致；没有“运行时使用旧观察器、报告引用新脚本”的漂移。
- `evidence/revision.patch` 的 SHA-256 与本机 `git diff 166a… 45063…` 精确相同：`1ae8c374450ba04b67c91f43b87736661107384f1ef257f6ce7da94dd5ed5716`。
- 四臂记录的 Python、包版本、GPU 型号/UUID/驱动及平台相同。真实 TP=2、mp、两个独立 Worker PID；脚本和服务日志均对应原生 Qwen-Image，512×512、20 步、BF16、eager、capacity=2。FlashInfer ring 可选后端的版本不匹配已披露，不将 TP2/SP1 成功扩展为 ring 后端验证。
- manifest 对模型 revision 和 before/after SHA 的文本字段是脚本写入的固定说明，不能单独充当证明；本次核验使用实际生产文件和脚本字节哈希。模型权重只有既有文件名/大小校验及原生加载成功证据，没有重新计算全部权重内容哈希。

### 原生矩阵：非空观测、输出与时间顺序

每臂 `cases.jsonl` 确实包含 13 个不同场景记录，每场景都包含 rank 0、1；各 rank 的 case snapshot 与对应原始 rank JSONL 完全一致。每次 snapshot 位于该场景最后一个真实执行步骤之后、下一场景第一个执行步骤之前。脚本控制流也保证消费者退出、采样完成后才提交下一场景，最后场景采样后才 shutdown。

独立按当前场景的 request ID 匹配弱引用，得到每个版本、每个 rank 的 **108 个目标请求状态、216 个私有 CUDA 张量**，每个请求都有两个非空 CUDA 张量观察（正/负 prompt embedding）。这排除了只对空字典或仅旧场景记录断言的可能。包含启动 dummy 后，最终累计是 109 个状态、217 个私有张量。两版所有适用空闲点的已观察状态与私有张量均死亡；Runner cache、batch IDs、batch states 均为空。

| 按每个 rank 重新计算 | reviewed `166a` | fixed `45063` |
| --- | ---: | ---: |
| 13 次空闲中 Worker LoRA 元数据残留次数 | 9 | 0 |
| 目标请求完成 / 取消 | 55 / 53 | 55 / 53 |
| 每次空闲 allocated | 42,916,440,576 B | 42,916,440,576 B |
| 每次空闲 reserved | 44,379,930,624 B | 44,379,930,624 B |

`summary.failed_cases` 中 baseline 是 8，因为 summary 不包含单独记录的 warmup；把 warmup 计入 13 次观察后是 9，发布材料已经采用带说明的计数。52 行 `idle-memory.csv` 与两臂 × 13 场景 × 2 ranks 的原始数值逐一相同。相等的 allocated 支持本轮是 Worker CPU 记账收尾，没有额外 GPU 显存收益。

108 个终止结果均为预期的完成或取消，无错误或缺少结果。55 个完成结果全部 finite、shape 为 `[1, 3, 512, 512]`、标准差非零；按请求 ID 一一比较的 before/after 输出 SHA-256 全部相等。这是固定 prompt/seed 的重复执行，共四种不同图像哈希，不是 55 个不同内容的质量评测。本地未同步 `.pt` 输出，本审查核对的是原生消费脚本产生的完整 tensor-byte 哈希及原始记录；没有重新对输出数组计算哈希。HTTP warmup PNG 则在本地直接重算并确认前后文件哈希相同。

Qwen 的单独完成输出与同批存活输出哈希不同，两版都如此；发布材料正确限定为相同调度配置的 before/after 输出一致，未把 OmniVoice 的跨 batch 相等推广给 Qwen。

三轮 C32 每轮确有 32 个提交、16 完成、16 取消，capacity 始终为 2。原始 rank-0 step 日志逐轮包含 167 次 B2 和 2 次 B1，总共 169 个 `make_batch` 调用；汇总中的 host 中位数与总时间可从日志精确重算。此计时是 **rank 0 的 host 调用耗时**，包括缓存路径，不代表 169 次完整重建或 GPU kernel 用时；两版已含原 Runner 清理，也不能据此量化其最初引入的开销。已建议发布材料保留样本值，避免“无明显 packing overhead”这类超出对照范围的表述。

### HTTP：真实活跃取消与各 rank 收尾

前后两臂各有实际 HTTP warmup 及断连请求。独立检查每个 rank 的日志：目标执行了两个步骤；两次步骤返回时目标仍在 Runner cache；唯一 cleanup release 的 `cache_before` 仍包含目标，release 后移除；随后 idle snapshot 到来，release 后没有任何新 step。目标 state 和两个私有 CUDA 张量有明确记录且均已释放。两 rank 都完成这一顺序，不是只检查 rank 0。

前后断连到最后 rank release 的记录分别是 **274.8399 ms / 276.7758 ms**，精确对应报告的 274.8/276.8 ms。两个 HTTP 运行退出码均为 0，取消后 allocated/reserved 与原生矩阵一致且相对 warmup 不变。取消在 reviewed head 已清理；正常完成 warmup 的 Worker 元数据残留在 before 有、after 无，符合本轮修复范围。

直接对本地 HTTP warmup PNG 重算的前后 SHA-256 都是 `28b7c8c980a421dc833c02f47d263e5550184a94ced11556589d1e4e1494aa3b`。HTTP 断连验证服务端取消传播和 collective cleanup；已断开的 HTTP 客户端不能证明仍在等待的消费者收到终止事件，这由独立 Engine 消费者测试覆盖。

同时补充前文本机 HTTP 数字的版本边界：42.2 ms 是初次观察，原文件现已另存到本机 `evidence/omnivoice-http-first-observation/`，本次归档不包含该历史目录；前文的首轮描述不指当前 `omnivoice-http-after/` 内容。正式 OmniVoice 证据已经重跑，当前 `omnivoice-http-after/`、正式报告与发布材料使用 **61.2 ms**，不混用两次运行。

### 发布材料与归档检查

复读 README、PR 正文、review comment 和 Qwen 最终报告，核心结论与原始证据相符：区分 `f69` 最初尾批滞留和 `166a` 本轮对照、CPU 元数据和 GPU allocation、C32 和 B32、TP2 和 ring 后端、输出哈希一致和主观质量。没有发现新的生产正确性阻断点或证据与结论矛盾。

按照当时 `build_bundle.py` 的筛选规则只读列出归档候选并扫描凭据模式，通过；四臂的双 rank 日志、manifest、退出码和 CSV 均在候选中，权重、`.pt` 和 Python cache 排除。此处不是已上传 ZIP 的完整性证明：最终归档须在本节写入后重新生成，并使用其 `SHA256SUMS`、ZIP 测试及发布 SHA。原报告指向 archive 外部的相对链接已改为此前公开 GitHub 证据链接，rank-0 host 计时范围也已写明；发布前还需替换附件 URL/SHA 占位。

本次未写 GitHub 评论、变更服务或提交代码。远端服务恢复文件记录原服务 PID 12973 已 RUNNING，2026-10-11 04:25:06 UTC 的 `/health` 返回 200；这里只核对保存的记录，没有重新访问远端服务。
